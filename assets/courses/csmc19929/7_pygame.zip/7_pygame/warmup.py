import pygame

# TODO 1: Setup the PyGame window (initialize pygame, configure the display, and set the display caption)


class Player(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.image = # TODO 2: Set the sprite image to be the image `sprite.png` provided. HINT: look into the functions in the pygame.image module

        # rect controls position and is used for drawing/collision
        self.rect = self.image.get_rect(topleft=(x, y))
        self.vel = vel

    def update(self, keys):
        # TODO 3: Complete the update function, which controls the sprite's position (or movement) in the PyGame window. HINT: This should be modifying `self.rect` 

player = Player(50, 50, 40, 60)

# A Group lets you update/draw many sprites at once with one call each.
all_sprites = pygame.sprite.Group()
all_sprites.add(player)

run = True

# This while loop both starts the game, and keep the game running
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # The next two lines monitor for key presses, and send them to be handled by the update function in Player
    keys = pygame.key.get_pressed()
    all_sprites.update(keys)

    win.fill((255, 255, 255))  # Fills the screen with white
    all_sprites.draw(win)
    pygame.display.update()

pygame.quit()
