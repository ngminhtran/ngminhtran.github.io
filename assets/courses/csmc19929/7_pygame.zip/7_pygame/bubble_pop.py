"""Exercise 1 - Bubble Pop

Fill in the code at/below each TODO comment, to complete the Bubble Pop game.

The game will show a screen with a solid colour and bubbles will show up randomly on the screen.
The bubbles shrink over time and your objective is to pop them before they disappear.
"""

import random
import time

import pygame

SIZE = 400
FPS = 60
BUBBLE_COLOUR = (248, 248, 242)
TEXT_COLOUR = (255, 255, 255)
BACKGROUND_COLOUR = (40, 42, 54)
GAME_DURATION = 60  # seconds
BUBBLE_RADIUS_DECAY = 0.1
BUBBLE_INTERVAL = 2  # seconds
BUBBLE_RADIUS = 30

screen = pygame.display.set_mode((SIZE, SIZE))

"""TODO 1: Complete the class `Bubble` below that manages the bubbles for the game.

1. Finish the `__init__` for Bubble. It should set three self variables, x, y, and radius, where x and y are two random integers < SIZE
    HINT: Use random.randint() to assign x and y

2. Complete function `draw()` so that it will draw a circle with color `BUBBLE_COLOUR`, centered at (self.x, self.y) with radius self.radius, and thickness (`width`) of 2.
    HINT: Use this reference for pygame.draw.circle: https://www.pygame.org/docs/ref/draw.html#pygame.draw.circle
"""

class Bubble:
    def __init__(self, radius):
        # TODO: Complete

    def draw(self, screen):
        # TODO: Complete

    def is_popped(self, click_x, click_y):
        dx = click_x - self.x
        dy = click_y - self.y
        return dx**2 + dy**2 <= self.radius**2

    def update(self):
        self.radius -= BUBBLE_RADIUS_DECAY
        return self.radius


pygame.font.init()
font = pygame.font.Font(size=SIZE // 20)

clock = pygame.time.Clock()
next_bubble = time.time()
bubbles = []
stop_at = time.time() + GAME_DURATION
popped = 0
failed = 0
while time.time() < stop_at:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.dict["button"] == pygame.BUTTON_LEFT:
                click_x, click_y = event.dict["pos"]
                bubbles_on_screen = len(bubbles)
                bubbles = [
                    bubble
                    for bubble in bubbles
                    if not bubble.is_popped(click_x, click_y)
                ]
                popped += bubbles_on_screen - len(bubbles)
"""TODO 2: Add an event handler / conditional that checks if the event was a `pygame.QUIT`, and if so, exists the game"""
        # TODO: Complete

    bubbles_on_screen = len(bubbles)
    bubbles = [bubble for bubble in bubbles if bubble.update() > 0]
    failed += bubbles_on_screen - len(bubbles)

    now = time.time()
    if now >= next_bubble or not bubbles:
        bubbles.append(Bubble(BUBBLE_RADIUS))
        next_bubble = now + BUBBLE_INTERVAL

    screen.fill(BACKGROUND_COLOUR)
    for bubble in bubbles:
        bubble.draw(screen)

    score = f"popped: {popped}; missed: {failed}"
    score_text = font.render(score, True, TEXT_COLOUR)
    screen.blit(score_text, (10, 10))
    pygame.display.flip()

score = f"popped: {popped}; missed: {failed}"
print(score)

screen.fill(BACKGROUND_COLOUR)
score_text = font.render(score, True, TEXT_COLOUR)
text_width, text_height = score_text.get_size()
screen.blit(
    score_text,
    (
        SIZE // 2 - text_width // 2,
        SIZE // 2 - text_height // 2,
    ),
)
pygame.display.flip()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()
