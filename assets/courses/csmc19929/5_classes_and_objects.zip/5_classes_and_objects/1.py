#!/usr/bin/env python
# coding: utf-8


"""Exercise 1

Add a variable `gender` (a string) to the Person class and adapt the initialisation method accordingly. Also add a method `ismale()` that uses this new information and returns a boolean value (True/False).
"""

# TODO: adapt the code below


class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def introduceyourself(self):
        print("My name is " + self.name)
        print("My age is " + str(self.age))


author = Person("Maarten", 30)
author.introduceyourself()
