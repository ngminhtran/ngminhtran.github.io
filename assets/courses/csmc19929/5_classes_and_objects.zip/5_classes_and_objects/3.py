#!/usr/bin/env python
# coding: utf-8

"""Exercise 3

Your task is to write a class called `FoodItem`. The class constructor should initialize a new food item given a name and amounts of fat, carbs, and protein (in grams). The class should also have a method called `get_calories` which returns the estimated amount of calories in a serving of the food item.

To estimate calories x given the grams of fat f, carbs c, and protein p, you should use the following approximation:

x = 9f + 4c + 4p

Write python code to do the following:

* Define a class called `FoodItem`.
* Define the class constructor to accept as arguments a string `name` and floats `fat`, `carbs`, and `protein`. The values from these argument should be stored as data members, so that they can be used in other methods.
* Define a method within `FoodItem` called `get_calories`, which accepts no arguments (other than `self`) and returns the estimated calories, as a float.
"""

# TODO: Replace this line with your solution.

# This creates a FoodItem object so you can test your class
snack = FoodItem("M&Ms", 10.0, 34.0, 2.0)
# This calls the get_calories method on the newly created FoodItem object
print(snack.get_calories())
