#!/usr/bin/env python
# coding: utf-8

"""Exercise 4

Your task is to write a class called `Circle`. The class constructor should take as input a radius that defaults to a value of `1.0`. The class should have methods called `area` and `perimeter` which return as floats the area and perimeter of the circle, respectively.

Be sure to use the math module (`import math`) and reference `math.pi` in your calculations.

Write python code to do the following:

* Define a class called `Circle`.
* Define the class constructor to accept as argument a float `radius` with a default value of `1.0`. This value should be stored as a data member, so that it can be used in other methods.
* Define a method within `Circle` called `area`, which accepts no arguments (other than `self`) and returns the area, as a float.
* Define a method within `Circle` called `perimeter`, which accepts no arguments (other than `self`) and returns the perimeter, as a float.
"""

# TODO: Replace this line with your solution.

# This creates a Circle object so you can test your class
c = Circle(8.0)
# These call the area and perimeter methods on the newly created Circle object
print(c.area())
print(c.perimeter())
