#!/usr/bin/env python
# coding: utf-8

"""Exercise 2

Write a second class called `Teacher` that inherits from the class `Person`. Add a method to `Teacher` called `stateprofession()` that states "I am a teacher!".

Afterwards, initialize this new class, and call its `introduceyourself()` and `stateprofession()` functions.
"""


class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def introduceyourself(self):
        print("My name is " + self.name)
        print("My age is " + str(self.age))


# TODO 1: Replace this line with your solution.

# -------------------------------------------------

# Consider a modified version of class `Person` below, that already has a `stateprofession()` function. What would be printed when calling the `stateprofession()` function, in this case, and why?


class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def introduceyourself(self):
        print("My name is " + self.name)
        print("My age is " + str(self.age))

    def stateprofession(self):
        print("I have no profession :(")


# TODO 2: Replace this line with your solution.
