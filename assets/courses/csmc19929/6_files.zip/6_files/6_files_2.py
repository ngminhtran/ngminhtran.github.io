#!/usr/bin/env python
# coding: utf-8


"""Exercise 2

Working with the list below, write to a text file to location `Data/countries.txt` that contains the countries in the list in the order that they are given, each separated by a new line.
"""

country_list = [
    "Afghanistan",
    "Albania",
    "Algeria",
    "American Samoa",
    "Andorra",
    "Angola",
    "Anguilla",
    "Antarctica",
    "Antigua and Barbuda",
    "Argentina",
    "Armenia",
    "Aruba",
    "Australia",
    "Austria",
    "Azerbaijan",
]

# TODO: Replace this line with your solution.
