#!/usr/bin/env python
# coding: utf-8


"""Exercise 1

The 'Data' folder that exists in this directory contains a file named 'sonnet116.txt'. It is the full text of a Shakespeare sonnet.

Print the poem on your screen, and make sure that you also add line numbers, as follows:

1. [line1]
2. [line2]
"""

# TODO: Replace this line with your solution.
