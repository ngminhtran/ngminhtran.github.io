#!/usr/bin/env python
# coding: utf-8

"""Exercise 2

Strings can be viewed as collections of characters.
When you iterate across a string using a `for` loop, you will receive each individual character in sequence.
Try to write code which prints each character of the string on a separate line.
"""

text = "Flow control"

# TODO: Replace this line with your solution.
