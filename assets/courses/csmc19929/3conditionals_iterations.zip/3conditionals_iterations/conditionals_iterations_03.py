#!/usr/bin/env python
# coding: utf-8

"""Exercise 2

The list named `years` brings together a number of years.  Use the keywords `for` and `if` to select the years from this list that are in the 18th century.  Remember that you can combine multiple Boolean expressions using `and`.
"""

years = [1756, 1575, 2002, 1984, 1626, 1791, 1714, 1873, 1991]

# TODO: Print years that are in the 18th century. Replace this line with your solution.
