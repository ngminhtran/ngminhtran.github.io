#!/usr/bin/env python
# coding: utf-8

# TODO: Replace this line with your solution.

"""Exercise 1

Write a function which takes a Python list as a parameter. This list should contain numbers. The function should return the average value of the numbers in the list. Name the function `calculate_average()`. in the definition of this function, add an optional parameter which specifies the number of digits that are returned after the digit. The default value must be 1.

To calculate the sum of all the numbers in a list, you can work with the `sum()` function.
"""

numbers = [6, 67, 8, 33, 24, 11, 34, 6, 23, 4, 19, 6, 9, 12, 134, 45, 23]

# TODO: Replace this line with your code for function `calculate_average()`.

# The below line can be used to test your solution>
print(calculate_average(numbers, 4))
