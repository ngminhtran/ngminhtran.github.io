#!/usr/bin/env python
# coding: utf-8

"""Exercise 5
We have a list of websites and are interested to find the Dutch ones.

Write some code to select the Dutch websites from this list (the ones ending with ".nl")
"""

websites = [
    "https://www.universiteitleiden.nl",
    "https://www.stanford.edu",
    "https://www.uu.nl",
    "http://www.ox.ac.uk",
    "https://www.rug.nl",
    "https://www.hu-berlin.de",
    "https://www.uva.nl",
]

# Print the URLs that belong to Dutch institutions
# TODO: Replace this line with your solution.
