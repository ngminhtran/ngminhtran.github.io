#!/usr/bin/env python
# coding: utf-8

"""Exercise 6
We have a list of websites and are interested to find the ones that belong
to U.S.-affiliated postsecondary institutions, which have the top-level domain ".edu".

Write some code to select the websites ending with ".edu" from this list.
"""

websites = [
    "https://www.uchicago.edu/",
    "https://www.arizona.edu/",
    "http://www.ox.ac.uk",
    "https://www.rug.nl",
    "https://www.wisc.edu/",
    "https://www.stanford.edu",
    "https://www.hu-berlin.de",
    "https://www.uva.nl",
    "https://www.berkeley.edu/",
]

# Print the URLs that belong to U.S.-affiliated postsecondary institutions.
# TODO: Replace this line with your solution.