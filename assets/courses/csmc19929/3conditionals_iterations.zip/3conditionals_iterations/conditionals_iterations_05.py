#!/usr/bin/env python
# coding: utf-8

"""Exercise 5

We have two lists of numbers and would like to know which numbers in the first list are not in the second list.
Write code which can extract those numbers from the first list that are **not** in the second list.
"""

first = [4, 9, 1, 17, 11, 26, 28, 54, 63]
second = [8, 9, 74, 21, 45, 11, 63, 28, 26]

numbers_not_in_second = []

# Add the numbers from `first` that are not in `second` to `numbers_not_in_second`

# TODO: Replace this line with your solution.

print(numbers_not_in_second)
