#!/usr/bin/env python
# coding: utf-8

"""Exercise 3

Building on the code you developed for exercise 5.2, try to write code which can reverse the order of the characters in a given string.

For example, "drawer" --> "reward"

Start by defining an empty output string, as follows.

```
output_string = ''
```

Next, iterate across all the individual characters of the string and append the output string *to the right of* this character.

Print the result.
"""

output_string = ""
# TODO: Replace this line with your solution.
