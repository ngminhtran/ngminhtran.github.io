#!/usr/bin/env python
# coding: utf-8

"""Exercise 1
Write some code which can print a text to welcome its users with messages such as 'Good morning', 'Good afternoon', or 'Good evening'. The message that is printed should vary along with the time of the day.

Follow the steps below:
    * Create a variable named `hour`
    * Assign it a value in between 0 and 23.
    * Assuming that this variable represents a given time, print a message that is appropriate for the part of the day this hour is in. If the variable `hour` has value 10, for instance, the code should print `'Good morning!'` and if `hour` has value 23, the code should print `'Good night!'`
"""

# TODO: Replace this line with your solution.
