#!/usr/bin/env python
# coding: utf-8

"""Exercise 08

Debug the code below. The code does not contain a syntax error but a semantic error. Do you understand what happens in the code as given?
"""

# TODO: Modify the code to make the value printed in the print statement is correct.

nr_weeks = "4"
print(f"Number of days in 4 weeks: {nr_weeks*7}")