#!/usr/bin/env python
# coding: utf-8

"""Exercise 6

The variables a, b and c in the cell below have all been assigned value 0.
Reassign values to these variables, in such as way that the four boolean expressions that follow are ALL evaluated as True.
"""

# TODO: Modify the code following the exercise instructions above.

a = 0
b = 0
c = 0

print(a < b)
print(b > c)
print(c < a and b > a)
print(b == c or b >= a)