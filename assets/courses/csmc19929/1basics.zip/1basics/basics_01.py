#!/usr/bin/env python
# coding: utf-8

"""Exercise 1

Below, we created two variables named `colour1` and `colour2`, and assign the strings "blue" and "yellow" to these two variables, respectively.

Write some code which can swap the values of these two variables.
In other words, make sure that, at the end of the program,
`colour1` has value 'yellow' and `colour2` has value 'blue'.

Tip: You can do this by working with a third variable named `swap`,
for example, which temporarily stores the value of one of these two variables.
"""

colour1 = "blue"
colour2 = "yellow"

# Use swap to "back up" the colour1 value before assigning colour2's value to colour1
# TODO: Replace this line with your solution.

# Restore the original value of colour1 to colour2
# TODO: Replace this line with your solution.

print(colour1)
print(colour2)
