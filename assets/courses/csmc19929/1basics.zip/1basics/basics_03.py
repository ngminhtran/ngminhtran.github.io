#!/usr/bin/env python
# coding: utf-8

"""Exercise 3

As explained in class, you can work with variables in calculations. The code below gives an example.

(1) Convert the type of variable 'a' to a floating point number using the `float()` function.
What is the type of variable that results from the addition?

(2) Convert the type of variable 'a' into a string, using the `str()` function.
What happens when you try to run this code?

Answer question 3.1 and 3.2 on Gradescope. For this exercise, you don't need to submit your code!
"""

a = 3
b = 4
c = a + b
print(c)