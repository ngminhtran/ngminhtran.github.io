#!/usr/bin/env python
# coding: utf-8

"""Exercise 07

Given an exchange rate of 1.2408 (euros to American dollars), how many dollars is equal to 150 euros?
To do this calculation, you need to multiply the exchange rate with the original amount of money.

Use the in-built round() function to ensure that the floating point number that results from the calculation
is shown as an actual amount, indicating the number of cents. The first parameter of round() is the number
to be rounded, and the second number is the number of digits beyond the decimal point.

Finally, print the result into the following sentence: '150 euros are worth X dollars', where 'X' with the amount of money you calculated.
"""

euros = 150

# TODO: Replace this line with your solution.
