#!/usr/bin/env python
# coding: utf-8

"""Exercise 5
Import the math module, as follows:

```
from math import *
```

This command imports all the available functions from the `math` module.

Use the functions `log10()`, `pow()`, `sqrt()` and `cos()` to generate the following numbers:

* The base-10 logarithm of 5.
* 3 raised to the power of 4
* The square root of 144
* The cosine of 60 radians.
"""

# TODO: Replace this line with your import of the math module/library.

# TODO: Replace this line with your code to compute and print the four numbers described above.