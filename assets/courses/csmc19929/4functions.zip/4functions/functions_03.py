#!/usr/bin/env python
# coding: utf-8

"""Exercise 3

In a course, the final grade is determined by grade for essay and by the grade for a presentation.
The presentation counts for 30% and the essay for 70%.

Write two functions:

1. `calculate_grade` should calculate the final grade based on a set of partial grades according to the given formula. Grades must be rounded to integers. 5.4, for example, becomes 5 and 6.6 becomes 7.
2. `pass_or_fail` should determine whether a given grade is at a pass level (i.e. equal to or higher than 6).This function must return a string value, 'Pass' or 'Fail'.
"""

# TODO: Write function `calculate_grade()`. It determines the final grade, based on the grades for the essay and presentation

# TODO: Write function `pass_or_fail()`. It determines 'Pass' or 'Fail', based on a single grade

# TODO: Write code to test your functions.
