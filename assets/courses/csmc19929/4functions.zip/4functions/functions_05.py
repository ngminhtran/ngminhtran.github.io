#!/usr/bin/env python
# coding: utf-8

"""Exercise 5

Write a function which can find and return the largest value in a list of numbers.
You MUST NOT use the `max()` built-in function in Python.
"""

# TODO: Replace this line with your solution. Make sure to test your function!