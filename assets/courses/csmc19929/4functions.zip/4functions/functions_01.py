#!/usr/bin/env python
# coding: utf-8

"""Exercise 2

Write a function which can convert a given temperature in degrees Celcius into the equivalent in Fahrenheit.
Use the following formula: F = 1.8 * C + 32.
"""

# TODO: Replace this line with the function `celcius_to_fahrenheit()`

# Once the function is ready, test it with a number of values. 20 degrees Celcius ought to be converted into 68 degrees Fahrenheit, and 37 degrees Celcius should equal 98.6 degrees Fahrenheit.

print(celcius_to_fahrenheit(20))
print(celcius_to_fahrenheit(37))