#!/usr/bin/env python
# coding: utf-8

"""Exercise 2

Write a function which can test whether a given number is in between 10 and 20.
The function should return `True` if this is the case, and `False` if not.
The function should also return `False` is equal to 10 or to 20.
"""

# TODO: Replace this line with your solution.


# Tests for your function are below.
print(between_10_and_20(8))
print(between_10_and_20(14))
print(between_10_and_20(29))
print(between_10_and_20(20))
