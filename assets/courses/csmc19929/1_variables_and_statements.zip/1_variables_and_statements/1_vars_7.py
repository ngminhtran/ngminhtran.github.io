#!/usr/bin/env python
# coding: utf-8

"""Exercise 7

Try to debug the code in the cell below. Why does Python report an error? What can we do to perform the calculation?
"""

print("149" + 1)

# TODO 1: Replace this line with a comment describing the reason why Python reports the error.

# TODO 2: Replace this line with the code that fixes the error.
