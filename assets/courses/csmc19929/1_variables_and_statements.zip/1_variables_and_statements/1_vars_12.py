#!/usr/bin/env python
# coding: utf-8

"""Exercise 12

Debug the code below. The code does not contain a syntax error but a semantic error. Do you understand what happens in the code as given?
"""

nr_weeks = "4"
print(f"Number of days in 4 weeks: {nr_weeks*7}")

# TODO: Replace this line with a description of what is happening

# TODO: Copy the code, and modify it to make the value printed a true number
