#!/usr/bin/env python
# coding: utf-8

"""Exercise 6

If a specific hotel charges €90 per night, how much do guests need to pay if they want to book a room for three nights?

Write code that calculates, and prints the total amount.
"""

tariff = 90
# TODO: Replace this line with the code that calculates and prints the solution.
