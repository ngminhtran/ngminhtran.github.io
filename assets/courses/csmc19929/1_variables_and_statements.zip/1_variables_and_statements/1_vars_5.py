#!/usr/bin/env python
# coding: utf-8

"""Exercise 5

As will be explained in the next notebook, you can work with variables in calculations. The code below gives an example.

a = 3
b = 4
c = a+b
print(c)

What happens when you try to make calculations with numbers that have different types?

(1) Copy the code below, and convert the type of variable 'a' to a floating point number using the `float()` function. What is the type of variable that results from the addition?

(2) Copy the code below, and convert the type of variable 'a' into a string, using the `str()` function. What happens when you try to run this code?
"""

a = 3
b = 4
c = a + b
print(c)

# TODO (1): Replace this line with your code showing the conversion, and a comment saying the type of variable that results from the addition.

# TODO (2): Replace this line with your code, and a comment describing the behavior for when you try converting `a` into a string in the skeleton code, and running it.
