#!/usr/bin/env python
# coding: utf-8

"""Exercise 8

Declare three numerical variables with arbitrary values. Declare another that calculates the average of these three values. Print the average.
"""

# TODO: Replace this line with your solution.
