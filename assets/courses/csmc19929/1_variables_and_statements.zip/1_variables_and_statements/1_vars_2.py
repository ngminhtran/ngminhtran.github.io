#!/usr/bin/env python
# coding: utf-8

"""Exercise 2

Using a single print statement, try to produce the output found between the two sets of ```:

This is the first line.
This second line. contains a        tab.
"""

# TODO: Replace this line with your solution.
