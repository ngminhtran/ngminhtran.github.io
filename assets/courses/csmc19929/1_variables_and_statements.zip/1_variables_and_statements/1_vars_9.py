#!/usr/bin/env python
# coding: utf-8

"""Exercise 9

Write code that calculates and prints the number of seconds in seven days. Print the result as a sentence, e.g.,

    "Seven days last X seconds."

where X is the result of the calculation.

HINT: Assign different variables for different constants, to help your calculation.
"""

# TODO: Replace this line with your solution.
