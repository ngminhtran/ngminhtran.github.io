#!/usr/bin/env python
# coding: utf-8

"""Exercise 4

Debug the code below, and submit a version that resolves these errors.
"""

print( 'It's not always easy to see the mistakes in your code.' )
print( "The ability to debug can be really useful.'' )
print( Don't forget to read the error messages!
      They're often very useful.)
