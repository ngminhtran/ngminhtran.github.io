#!/usr/bin/env python
# coding: utf-8

"""Exercise 1

Write code that can print the sentence “Hello world” or any other sentence that you can think of.
"""

# TODO: Replace this line with your solution.
