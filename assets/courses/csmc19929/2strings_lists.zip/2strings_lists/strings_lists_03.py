#!/usr/bin/env python
# coding: utf-8

"""Exercise 3

Create two string variables. The first variable must be assigned the value 'unique',
and the second variable should be assigned the value 'biodiversity'.

Create a third variable with the value 'university', by firstly slicing the first two variables, then concatenating the substrings.
"""

# TODO: Replace this line with your solution.