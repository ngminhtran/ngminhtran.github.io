#!/usr/bin/env python
# coding: utf-8

"""Exercise 6

The list named `titles` below brings together a number of book titles.

First, print a sentence that gives information about the number of books in this list of titles.

Then, print the title "Prisoner of Azkaban" using the index of it in the list.

Next, create a new list named `last_three` containing only the last three titles in this series.
"""

titles = [
    "Philosopher's Stone",
    "Chamber of Secrets",
    "Prisoner of Azkaban",
    "Goblet of Fire",
    "Order of the Phoenix",
    "Half-Blood Prince",
    "Deathly Hallows",
]

# TODO: Replace this line with your solution.
