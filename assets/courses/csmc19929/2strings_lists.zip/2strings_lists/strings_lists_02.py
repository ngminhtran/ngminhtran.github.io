#!/usr/bin/env python
# coding: utf-8

"""Exercise 2

Create a variable and assign it your full name as a string.
Next, print the number of characters in your name, excluding the space(s).

Tip: to remove the spaces, you can replace these with an empty string ('').
"""

# TODO: Replace this line with your solution.