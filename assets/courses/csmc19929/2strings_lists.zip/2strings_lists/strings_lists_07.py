#!/usr/bin/env python
# coding: utf-8

"""Exercise 7

Create a list name `cities` that consists of the followng cities: New York, Los Angeles, Chicago, Houston, Phoenix

Next, write code to add two more cities Philadelphia and San Antonio to this list.

Finally, create a new list named `sorted_cities` in which the elements are sorted alphabetically.

"""

# TODO: Replace this line with your solution.
