#!/usr/bin/env python
# coding: utf-8

"""Exercise 1

Declare a variable named `year`, and assign it an integer with the value 1879.
Next, use this variable to print the following sentence: "Albert Einstein was born in 1879".

You MUST use the `year` variable you declared in your print statement.
In other words, `print("Albert Einstein was born in 1879")` is an incorrect solution.
"""

# TODO: Replace this line with your solution.