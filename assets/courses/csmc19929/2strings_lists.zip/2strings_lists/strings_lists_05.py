#!/usr/bin/env python
# coding: utf-8

"""Exercise 5

Create a variable named `url` and assign it following string: 'https://www.uchicago.edu'.

Try to write code which can extract the top-level domain (i.e. "edu") from this url.

Tip: This problem can be solved by creating a string slice with the last three characters only,
but top-level domains may consist of more or less than three characters, like '.us' or '.shop'.

Try to use a more generic approach using the rindex() built-in method, which returns the LAST occurrence of a character.
"""

url = "https://www.uchicago.edu/"

# TODO: Replace this line with your solution.