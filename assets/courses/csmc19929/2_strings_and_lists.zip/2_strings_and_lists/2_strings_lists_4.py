#!/usr/bin/env python
# coding: utf-8

"""Exercise 4

Create the following two string variables:

```
first = 'vladimir'
last = 'nabokov'
```

Using these two existing variables, create a third variable named `full_name` with the following value: “Nabokov, Vladimir”. Note that the first character of the first name and the last name must be in upper case.
"""

# TODO: Replace this line with your solution.
