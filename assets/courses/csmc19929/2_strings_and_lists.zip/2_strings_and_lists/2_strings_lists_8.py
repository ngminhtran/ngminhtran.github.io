#!/usr/bin/env python
# coding: utf-8

"""Exercise 8

Create the following list:

``
colours = ['green','blue','red']
``

Add the colours 'orange', 'yellow' to this list.
"""

# TODO: Replace this line with your solution.
