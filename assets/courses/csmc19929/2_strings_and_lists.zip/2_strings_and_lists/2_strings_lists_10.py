#!/usr/bin/env python
# coding: utf-8

"""Exercise 10

The list below contains the titles of first twelve plays written by William Shakespeare.
"""

plays = [
    "Comedy of Errors",
    "Henry VI, Part I",
    "Henry VI, Part II",
    "Henry VI, Part III",
    "Richard III",
    "Taming of the Shrew",
    "Titus Andronicus",
    "Romeo and Juliet",
    "Two Gentlemen of Verona",
    "Love's Labour's Lost",
    "Richard II",
    "Midsummer Night's Dream",
]

# Add the following two titles to this list: Macbeth, Othello
# TODO: Replace this line with your solution.

# Next, count the number of plays in this list.
# TODO: Replace this line with your solution.

# Print the titles of the first and the last plays in the list, using the index of these items.
# TODO: Replace this line with your solution.
