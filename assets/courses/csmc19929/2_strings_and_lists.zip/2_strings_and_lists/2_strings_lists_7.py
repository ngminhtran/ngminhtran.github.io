#!/usr/bin/env python
# coding: utf-8

"""Exercise 7

The list named `titles` below brings together a number of book titles. Print a sentence that gives information about the number of books in this list of titles.

Next, create a new list named `last_two` containing only the last two titles in this series.
"""

titles = [
    "Philosopher's Stone",
    "Chamber of Secrets",
    "Prisoner of Azkaban",
    "Goblet of Fire",
    "Order of the Phoenix",
    "Half-Blood Prince",
    "Deathly Hallows",
]

# TODO: Replace this line with your solution.
