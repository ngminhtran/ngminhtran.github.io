#!/usr/bin/env python
# coding: utf-8

"""Exercise 1

Declare a variable named `year`, and assign it an integer with the value 1879. Next, use this variable to print the following sentence: "Albert Einstein was born in 1879".
"""

year = 1879

# TODO: Replace this line with your solution.
