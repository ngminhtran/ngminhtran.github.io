#!/usr/bin/env python
# coding: utf-8

"""Exercise 6

Create a variable named `filename` and assign it the value 'README.txt'. Next, write some code in Python which can extract the filename without the extension.
"""

# TODO: Replace this line with your solution.
