#!/usr/bin/env python
# coding: utf-8

"""Exercise 5

Create a variable named `url` and assign it following string: `https://www.universiteitleiden.nl`.

Try to write code which can extract the top-level domain (i.e. the country code, "nl") from this url.
"""

url = "https://www.universiteitleiden.nl"

# TODO: Replace this line with your solution.
