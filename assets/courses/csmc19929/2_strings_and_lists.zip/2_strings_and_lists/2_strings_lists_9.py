#!/usr/bin/env python
# coding: utf-8

"""Exercise 9

Create the following list:

``
cities = ['Madrid','Helsinki','Paris','Brussels','London','Rome','Warsaw','Amsterdam']
``

Next, create a new list named `sorted_cities` in which the elements are sorted alphabetically.
"""

# TODO: Replace this line with your solution.
