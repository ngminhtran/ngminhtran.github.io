#!/usr/bin/env python
# coding: utf-8

"""Exercise 2: Events & Keyboard Input

The lecture showed two ways to read keys:
  (A) pygame.event.get() --> detects the MOMENT a key is pressed (KEYDOWN)
  (B) pygame.key.get_pressed()  -->  reads keys that are HELD DOWN RIGHT NOW.
This exercise practices both.

Your task:
  - The circle starts at the center of the window.
  - Pressing the SPACE BAR (one tap) should toggle the circle's color
    between BLUE and YELLOW. Use approach (A) for this.
  - Holding the ARROW KEYS should move the circle continuously.
    Use approach (B) for this.
  - Pressing ESCAPE should close the window cleanly.
TIP: print() is extremely useful while debugging, it won't break the game.
"""

import pygame

pygame.init()

WIDTH, HEIGHT = 500, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Exercise 2: Events & Input")

WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
YELLOW = (255, 215, 0)

SPEED = 4   # these are pixels per frame

# starting position (center of screen)
x = WIDTH  // 2
y = HEIGHT // 2

colour = BLUE   # current circle colour

clock = pygame.time.Clock()
running = True

while running:
    clock.tick(60) # cap at 60 fps
    # (A) Event-based input
    for event in pygame.event.get():
        pass  # remove this line once you finish code for your TODOs below, this is a place holder

        # TODO 1: If the event type is pygame.QUIT, set running = False.


        # TODO 2: If the event type is pygame.KEYDOWN:
        # - If the key is pygame.K_ESCAPE, set running = False.
        # - If the key is pygame.K_SPACE, toggle `colour` between BLUE and YELLOW.
        # HINT: use an if/else, or the ternary colour = YELLOW if colour == BLUE else BLUE


    # (B) Continuous (held-key) input
    keys = pygame.key.get_pressed()

    # TODO 3: If K_UP is held, decrease y by SPEED.
    # TODO 4: If K_DOWN is held, increase y by SPEED.
    # TODO 5: If K_LEFT is held, decrease x by SPEED.
    # TODO 6: If K_RIGHT is held, increase x by SPEED.
    # Write your code below for these 4 TODOs


    # DRAWING part
    screen.fill(WHITE)
    pygame.draw.circle(screen, colour, (x, y), 30)
    pygame.display.flip()

pygame.quit()
