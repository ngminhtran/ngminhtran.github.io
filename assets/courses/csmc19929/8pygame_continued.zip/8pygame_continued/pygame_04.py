#!/usr/bin/env python
# coding: utf-8

"""Exercise 4: Collision Detection

Almost every mechanic in your game designs requires collision:
"walk into the NPC to talk", "enter the building", "don't walk through walls".

pygame.Rect has built-in collision helpers, no maths needed:
  rect_a.colliderect(rect_b) --> True if the two rectangles overlap
  rect.collidepoint((x, y)) --> True if the point is inside the rect

Your task:
    - A PLAYER (blue square, 40×40) starts in the centers and moves with arrow keys.
    - An NPC (green square, 50×50) sits near the top-right, notes that this one never moves.
    - A WALL (dark grey rectangle) blocks the bottom-left corner.
    - Actions:
        When the player's rect overlaps the NPC's rect:
        --> Display the message "Talking to NPC!" on screen (use pygame.font).
        When the player's rect overlaps the WALL's rect:
        --> Stop the player from entering the wall (push them back).
        HINT: after moving, check for collision and revert x or y if needed.
        Clamp the player so it cannot leave the window entirely.
        HINT: use max() and min(), or pygame.Rect.clamp_ip(screen.get_rect()).

Reference:
  https://www.pygame.org/docs/ref/rect.html#pygame.Rect.colliderect
"""

import pygame

pygame.init()

WIDTH, HEIGHT = 600, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Exercise 4: Collision")

WHITE = (255, 255, 255)
BLUE = (70, 130, 180)
GREEN = (60, 179, 113)
DARK_GREY = (50, 50, 50)
RED = (220, 50, 50)
BLACK = (0, 0, 0)

pygame.font.init()
font = pygame.font.Font(None, 36)

SPEED = 4

# game objects as pygame.Rect(left, top, width, height)
player = pygame.Rect(WIDTH // 2 - 20, HEIGHT // 2 - 20, 40, 40)
npc = pygame.Rect(WIDTH - 100, 50, 50, 50)
wall = pygame.Rect(0, HEIGHT - 120, 200, 120)

clock = pygame.time.Clock()
running = True

while running:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False

    # movement handling part
    keys = pygame.key.get_pressed()
    # TODO 1: Move the player with arrow keys (SPEED pixels per frame).
    # Store the old position first so you can revert on wall collision:
    # old_x, old_y = player.x, player.y
    # Then update player.x and player.y based on keys pressed.

    # TODO 2: Wall collision - if the player overlaps the wall, push them back.
    # HINT:
    #       if player.colliderect(wall):
    #           player.x = old_x (revert horizontal)
    #       if player.colliderect(wall):
    #           player.y = old_y (revert vertical)
    # (Reverting each axis separately lets the player slide along the wall)

    # TODO 3: Clamp the player inside the window.
    # HINT: player.clamp_ip(screen.get_rect())

    # DRAWING part
    screen.fill(WHITE)
    #   draw wall
    pygame.draw.rect(screen, DARK_GREY, wall)
    wall_label = font.render("WALL", True, WHITE)
    screen.blit(wall_label, (wall.x + 5, wall.y + 5))
    #   draw NPC
    pygame.draw.rect(screen, GREEN, npc)
    npc_label = font.render("NPC", True, WHITE)
    screen.blit(npc_label, (npc.x + 5, npc.y + 10))
    #   draw raw player
    pygame.draw.rect(screen, BLUE, player)

    # TODO 4: Check if the player rect collides with the NPC rect.
    # If yes, render and blit the message "Talking to NPC!" in RED,
    # centred near the bottom of the screen (y = HEIGHT - 50).
    # HINT: font.render(text, True, colour) then screen.blit(surface, pos)

    pygame.display.flip()
pygame.quit()
