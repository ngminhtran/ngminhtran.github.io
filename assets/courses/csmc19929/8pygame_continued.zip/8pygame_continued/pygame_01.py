#!/usr/bin/env python
# coding: utf-8

"""Exercise 1: Drawing Shapes

In the pygame lecture, you learned that pygame.draw lets you paint shapes onto the screen.
This exercise gets you comfortable with the coordinate system and the drawing functions
before we add any interaction.

Your task: complete the TODOs so that the window shows:
  - A white background
  - A red filled circle in the upper-left area
  - A blue outlined (hollow) rectangle in the center
  - A green diagonal line from the top-right corner to the bottom-left corner

Reference: (where you verify your syntax) https://www.pygame.org/docs/ref/draw.html

Run the file. When the window looks right, close it (click the X), that should exits cleanly.
"""

import pygame

pygame.init()

WIDTH, HEIGHT = 500, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Exercise 1: Drawing Shapes")

# colours (R, G, B)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 200, 0)

# From this point, this is the main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    # TODO 1: Fill the entire screen with WHITE.
    # HINT: screen.fill(colour)


    # TODO 2: Draw a RED filled circle.
    #   - centre position: (100, 100)
    #   - radius: 50
    # HINT: pygame.draw.circle(screen, colour, centre, radius)
    # NOTE: A width of 0 (the default) means filled.


    # TODO 3: Draw a BLUE *hollow* rectangle (outline only, thickness = 4).
    #   - position and size: left = 175, top = 175, width = 150, height = 150
    # HINT: pygame.draw.rect(screen, colour, pygame.Rect(left, top, width, height), width = 4)


    # TODO 4: Draw a GREEN line from the top-right corner to the bottom-left corner.
    #   top-right --> (WIDTH, 0)
    #   bottom-left --> (0, HEIGHT)
    #   line thickness: 3
    # HINT: pygame.draw.line(screen, colour, start, end, width)

    pygame.display.flip()

pygame.quit()
